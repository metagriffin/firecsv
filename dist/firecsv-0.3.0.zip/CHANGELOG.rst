=========
ChangeLog
=========


v0.3.0
======

* Converted to WebExtension for FF57 compatibility


v0.2.2
======

* Switched to underscore/1.6.0 (since 1.7.0 is not yet supported by
  AMO)


v0.2.1
======

* Added pie chart rendering of selection data
* Improved "install.rdf" to include Thunderbird & SeaMonkey


v0.1.0
======

* First public release
